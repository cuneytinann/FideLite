#!/usr/bin/env node
// =====================================================================
// newengine — standard test suite
//
// Same corpus, same depths and same reference values as the original
// FideLite suite, retargeted at the numeric newengine core.
//
// What changed versus the old harness, and why:
//
//   board      s[]  (ASCII letters, a8 = 0)   ->  b[]  (numeric, a1 = 0)
//   moves      G(i)                           ->  L(i)
//   apply      M(from,to,'q')                 ->  M(from,to,3)
//   en-passant Y   ('-' = none)               ->  e   (-1 = none)
//   halfmove   o                              ->  n
//   check      J(W)                           ->  l(g)
//   FIDE 6.9   Q(W)                           ->  H(g)
//
// Third retarget (readability rename). Same engine, same structure, same
// byte count: only the single-letter names were shifted, mostly by case.
// Two pairs SWAPPED roles, and they are the whole risk of this port:
//
//   castling mask    C      ->  c            castling bits    c()  ->  C()
//   legal moves      l(i)   ->  L(i)         check            L()  ->  l()
//
// The rest of the shift, for reference:
//
//   side to move     T      ->  t            threat flag      t    ->  T
//   en passant       E      ->  e            geometry         g()  ->  G()
//   FIDE 6.9         h()    ->  H()          threat test      v()  ->  V()
//   draw claim       X()    ->  D()          repetition count G    ->  $
//   horizontal dist  H      ->  h            vertical dist    V    ->  v
//   colour / side    O      ->  g            FIDE 6.9 scratch j    ->  O
//
// b, n, M(), I(), Z(), A(), F() keep their names, so FEN handling and the
// perft driver are otherwise untouched.
//
// Fourth pass (signature and layer order). The signed builds now open with
//   c=15,U=[600,600],N='indexOf',e=Y=-1,t=1
// U is the driver's clock as an array, N the indexOf alias (Q, where present,
// is innerHTML). L1/L2 carry no signature. Every build lists the rule layer
// first and the interface after it, which is what lets the loader below take
// any shipped file statement by statement. U and N are never read here.
//
// The index flip is the part that bites: every square number differs by
// ^56 between the two engines, so FEN parsing, square naming and the
// castling/en-passant fields all had to be rewritten rather than ported.
// Castling BIT semantics are unchanged (1=WK 2=WQ 4=BK 8=BQ) — verified
// against newengine's own c() rather than assumed.
//
// The engine is loaded as a bare core: no driver, no DOM, no prompt loop.
// M() is used (not O()) because perft must not touch castling rights,
// the repetition table or side-to-move — the harness owns those.
// =====================================================================

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { spawnSync } = require('child_process');

// Engine selection. Four builds can run this suite:
//
//   1  engine_4x.js                speed build, numeric board (+91 B, ~2-8x faster)
//   2  engine.js                   byte-record build, numeric board, full FIDE
//   3  engine_string.js            string board: b[] holds FEN letters, '-' is empty
//   4  engine_onlyMoveGenerator.js move generation only, no result; the side to move is t, as in L1
//
// The suite only ever exercises move generation — L(), M(), C() and G() — so every
// level can run it. What the lower levels drop (result codes, counters, material)
// is never called here; see cmdDetect for what each one actually carries.
//
// How the build is chosen, first match wins:
//   ENGINE=path            an explicit file, no prompt
//   --engine=N  /  -e N    one of the four by number, no prompt
//   interactive picker     arrows + Enter, or type 1-4; bare Enter takes 1
//   not a TTY (.bat, pipe) the first of the four present in this folder
//
// The picker draws on stderr and `node test.js pick` prints the chosen path on
// stdout, so a script can ask once and pin the answer for every run that follows:
//   for /f "usebackq delims=" %%e in (`node test.js pick`) do set "ENGINE=%%e"
//   ENGINE=$(node test.js pick)          # sh
const ENGINES = [
  { file: 'engine_4x.js',                what: 'speed build, numeric board' },
  { file: 'engine.js',                   what: 'byte-record build, numeric board' },
  { file: 'engine_string.js',            what: 'string board (FEN letters)' },
  { file: 'engine_onlyMoveGenerator.js', what: 'move generation only' },
];
const ENGINE_CANDIDATES = ENGINES.map(e => './' + e.file);
const here = f => path.join(__dirname, f);

function pickEngine(interactive) {
  if (process.env.ENGINE) return process.env.ENGINE;
  const argv = process.argv.slice(2);
  let n = null;
  for (let i = 0; i < argv.length; i++) {
    let m = /^--engine=([1-4])$/.exec(argv[i]);
    if (m) n = +m[1];
    else if (argv[i] === '-e' && /^[1-4]$/.test(argv[i + 1] || '')) n = +argv[++i];
  }
  if (n) return './' + ENGINES[n - 1].file;

  const present = ENGINES.map((e, i) => ({ ...e, i })).filter(e => fs.existsSync(here(e.file)));
  if (!present.length) return './engine.js';
  if (!interactive || !process.stdin.isTTY || !process.stderr.isTTY) return './' + present[0].file;

  let sel = present.findIndex(e => e.i === 0);
  if (sel < 0) sel = 0;
  const H = ENGINES.length + 3;
  const draw = first => {
    if (!first) process.stderr.write(`\x1b[${H}A`);
    process.stderr.write('\n  Which engine?   (arrows + Enter, or type 1-4; Enter alone takes 1)\n');
    ENGINES.forEach((e, i) => {
      const p = present.find(x => x.i === i);
      const cur = p && present[sel].i === i;
      const line = `   ${cur ? '>' : ' '} ${i + 1}  ${e.file.padEnd(28)} ${e.what}` +
                   (p ? '' : '   [not in this folder]');
      process.stderr.write(`\x1b[2K${cur ? '\x1b[1m' : p ? '' : '\x1b[2m'}${line}\x1b[0m\n`);
    });
    process.stderr.write('\n');
  };
  draw(true);
  const buf = Buffer.alloc(8);
  process.stdin.setRawMode(true);
  try {
    for (;;) {
      let k = 0;
      try { k = fs.readSync(0, buf, 0, 8); }
      catch (err) { if (err.code === 'EAGAIN') continue; throw err; }
      const key = buf.slice(0, k).toString('latin1');
      if (key === '\x03' || key === 'q') { process.stderr.write('\n'); process.exit(130); }
      if (key === '\r' || key === '\n') break;
      if (key === '\x1b[A' || key === 'k') { sel = (sel + present.length - 1) % present.length; draw(false); continue; }
      if (key === '\x1b[B' || key === 'j') { sel = (sel + 1) % present.length; draw(false); continue; }
      const d = /^[1-4]$/.test(key) ? +key : 0;          // a wrong key is simply ignored
      if (d) { const p = present.findIndex(x => x.i === d - 1); if (p >= 0) { sel = p; draw(false); } }
    }
  } finally { process.stdin.setRawMode(false); }
  return './' + present[sel].file;
}

let ENGINE_FILE = './engine.js';        // set from main(); readEngine() reads it at call time

// ============== Piece encoding ==============
// newengine: piece = type*2 + colour, colour bit 0 (1 = White), 0 = empty.
// type: 1 bishop, 2 rook, 3 queen, 4 pawn, 5 king, 6 knight.
const FROM_FEN = { b: 2, B: 3, r: 4, R: 5, q: 6, Q: 7, p: 8, P: 9, k: 10, K: 11, n: 12, N: 13 };
const TO_FEN = Object.fromEntries(Object.entries(FROM_FEN).map(([k, v]) => [v, k]));

// Promotion argument for M()/O(): the TYPE, not a lookup index.
const PROMO = { q: 3, r: 2, b: 1, n: 6 };

// ============== Board dialect ==============
// Two board encodings ship. Everything the suite does to a square goes through
// D, so the perft driver, the FEN codec and the move lists are written once.
//
//   numeric  b[i] = type*2 + colour, 0 empty, e = -1 when there is no ep square
//   string   b[i] = the FEN letter itself, '-' empty, e = '-' when there is none
//
// The string engine's M() uppercases a promotion for White on its own
// (`P&f%56<8?t?j(u):u:p`), so the promotion argument is always lower case.
const DIALECT_NUM = {
  string: false, EMPTY: 0, NOEP: -1,
  fromFen: ch => FROM_FEN[ch],
  toFen:   p  => TO_FEN[p],
  empty:   p  => !p,
  own:     (p, side) => !!p && (p & 1) === side,
  pawn:    p  => (p >> 1) === 4,
  promo:   q  => PROMO[q],
  noEp:    e  => e == null || e < 0,
};
const DIALECT_STR = {
  string: true, EMPTY: '-', NOEP: '-',
  fromFen: ch => ch,
  toFen:   p  => p,
  empty:   p  => p === '-',
  own:     (p, side) => p !== '-' && (p < 'a') === !!side,
  pawn:    p  => p === 'P' || p === 'p',
  promo:   q  => q,
  noEp:    e  => e == null || e === '-',
};
let D = DIALECT_NUM;      // set by loadEngine() from the board it finds

// ---- squares: newengine is a1 = 0, file = i&7, rank = i>>3 ----
// engine_string.js is a8 = 0: its squares are the numeric ones ^56.
const X = i => D.string ? i ^ 56 : i;
const sqName = i => String.fromCharCode(97 + (X(i) & 7)) + ((X(i) >> 3) + 1);
const nameSq = s => X((+s[1] - 1) * 8 + (s.charCodeAt(0) - 97));

// ============== Engine loading ==============
// Any shipped file can be handed over: a bare engine (.js), a plain build
// (.html / .cjs) or a RegPack-packed build. The loader does not look for a
// "driver starts here" marker any more — every build now opens with the rule
// layer and the interface follows it, but the first interface statement differs
// from build to build. Instead the script is split into its top-level
// statements and each one is evaluated on its own, in order; a statement that
// needs a DOM, prompt(), stdin or a timer simply throws and is skipped. The
// first loop (a prompt or stdin driver) ends the walk, so no game is started.
//
// The harness never reads U or N. U is the driver's clock (U=[600,600] in the
// engines, a timestamped array in L3.html), N is the indexOf alias in the signed
// builds and the innerHTML alias in L1/L2; neither is touched by perft.
function readEngine(p = ENGINE_FILE) {
  const full = path.isAbsolute(p) ? p : path.join(__dirname, p);
  if (!fs.existsSync(full)) {
    console.error(`ERROR: engine not found: ${p}`);
    console.error(`Looked next to test.js for, in order:`);
    for (const cand of ENGINE_CANDIDATES) console.error(`  ${cand.slice(2)}`);
    console.error(`Put one of them here, or set ENGINE=path`);
    process.exit(1);
  }
  let src = fs.readFileSync(full, 'utf8').replace(/^\uFEFF/, '');
  // Accept an .html wrapper too, so a shipped build can be tested directly.
  const m = src.match(/<script>([\s\S]*?)<\/script>/);
  if (m) src = m[1];
  // A RegPack build hands back its own source when eval(_) is captured.
  if (/eval\(_\)\s*$/.test(src)) {
    const box = {};
    vm.createContext(box);
    vm.runInContext(src.replace(/eval\(_\)\s*$/, '__src=_'), box);
    src = box.__src;
  }
  return src;
}

// Top-level statements, split on commas and semicolons outside brackets,
// strings, template literals and regex literals.
function splitTop(js) {
  const out = [], st = [];
  let cur = '';
  for (let i = 0; i < js.length; i++) {
    const ch = js[i], top = st[st.length - 1];
    if (top === "'" || top === '"') { cur += ch; if (ch === '\\') { cur += js[++i]; continue; } if (ch === top) st.pop(); continue; }
    if (top === '`') { cur += ch; if (ch === '\\') { cur += js[++i]; continue; } if (ch === '`') st.pop(); else if (ch === '$' && js[i + 1] === '{') { cur += js[++i]; st.push('${'); } continue; }
    if (ch === "'" || ch === '"' || ch === '`') { st.push(ch); cur += ch; continue; }
    if (ch === '/' && js[i + 1] !== '/' && /[=(,:?&|!;{}[]$/.test(cur.trimEnd())) {
      let j = i + 1, cls = 0;
      while (j < js.length) { if (js[j] === '\\') { j += 2; continue; } if (js[j] === '[') cls = 1; else if (js[j] === ']') cls = 0; else if (js[j] === '/' && !cls) break; j++; }
      j++; while (/[a-z]/.test(js[j] || '')) j++;
      cur += js.slice(i, j); i = j - 1; continue;
    }
    if ('([{'.includes(ch)) st.push(ch);
    else if (')]}'.includes(ch)) st.pop();
    if (!st.length && (ch === ',' || ch === ';')) { out.push(cur); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out;
}

function loadEngine(p = ENGINE_FILE) {
  const src = readEngine(p);
  const quiet = { log() {}, error() {}, warn() {} };
  const sb = { Math, String, Number, Array, Object, JSON, BigInt, Date,
               Int8Array, Int32Array, Uint8Array, console: quiet };
  vm.createContext(sb);
  let loaded = 0;
  for (const stmt of splitTop(src)) {
    if (/^\s*(for|while)\s*\(/.test(stmt)) break;          // a driver loop begins
    try { vm.runInContext(stmt, sb); loaded++; }
    catch (e) {
      // An interface statement fails when it runs (there is no DOM here).
      // A statement that does not even parse is a broken definition, never an
      // interface line: swallowing it once let an engine with a syntax error
      // in H() pass sanity 3/3.
      if (e && e.name === 'SyntaxError') {
        console.error(`ERROR: a statement does not parse: ${stmt.trim().slice(0, 60)}...`);
        console.error(`  ${e.message}`);
        process.exit(1);
      }
    }
  }
  if (!loaded) {
    console.error('ERROR: engine failed to load: no statement could be evaluated');
    process.exit(1);
  }
  // Only what the suite actually calls. l(), H(), I(), Z(), A(), D() and F()
  // are deliberately absent from the lower levels, and no test touches them —
  // requiring them here would lock the suite to the two full engines.
  for (const fn of ['L', 'M', 'C', 'G']) {
    if (typeof sb[fn] !== 'function') {
      console.error(`ERROR: engine is missing ${fn}() — is this a newengine core?`);
      process.exit(1);
    }
  }
  // The board tells us which dialect to speak. Both are supported.
  if (!Array.isArray(sb.b) && !(sb.b instanceof Int8Array)) {
    console.error('ERROR: no board b[] after loading');
    process.exit(1);
  }
  D = typeof sb.b[0] === 'string' ? DIALECT_STR : DIALECT_NUM;
  if (!Array.isArray(sb.L(12))) {
    console.error('ERROR: L(i) does not return a move list — this is an L(i,u) build (L1/L2 family), not supported');
    process.exit(1);
  }
  sb.__src = src;
  return sb;
}

// ============== FEN <-> engine state ==============
// FEN lists rank 8 first; newengine stores rank 1 first. Hence the flip.
function setFEN(env, fen) {
  const [pieces, side, castling, ep, halfmove] = fen.trim().split(/\s+/);
  const board = new Array(64).fill(D.EMPTY);
  let sq = 56;                       // a8 in newengine indexing
  for (const ch of pieces) {
    if (ch === '/') { sq -= 16; continue; }
    if (/\d/.test(ch)) { sq += +ch; continue; }
    if (!(ch in FROM_FEN)) throw new Error('bad FEN piece: ' + ch);
    board[X(sq++)] = D.fromFen(ch);
  }
  env.b = env.b instanceof Int8Array ? Int8Array.from(board) : board;
  env.t = side === 'w' ? 1 : 0;
  let cr = 0;
  if (castling && castling !== '-') {
    if (castling.includes('K')) cr |= 1;
    if (castling.includes('Q')) cr |= 2;
    if (castling.includes('k')) cr |= 4;
    if (castling.includes('q')) cr |= 8;
  }
  env.c = D.string ? cr >> 2 | (cr & 3) << 2 : cr;   // a8 = 0: K=4 Q=8 k=1 q=2
  env.e = (!ep || ep === '-') ? D.NOEP : nameSq(ep);
  env.n = halfmove ? +halfmove : 0;
}

function envToFEN(env) {
  let pieces = '';
  for (let r = 7; r >= 0; r--) {
    let row = '', empty = 0;
    for (let f = 0; f < 8; f++) {
      const p = env.b[X(r * 8 + f)];
      if (D.empty(p)) empty++;
      else { if (empty) { row += empty; empty = 0; } row += D.toFen(p); }
    }
    if (empty) row += empty;
    pieces += (r < 7 ? '/' : '') + row;
  }
  let castling = '';
  const c = D.string ? env.c >> 2 | (env.c & 3) << 2 : env.c;
  if (c & 1) castling += 'K';
  if (c & 2) castling += 'Q';
  if (c & 4) castling += 'k';
  if (c & 8) castling += 'q';
  if (!castling) castling = '-';
  const ep = D.noEp(env.e) ? '-' : sqName(env.e);
  return `${pieces} ${env.t ? 'w' : 'b'} ${castling} ${ep} ${env.n} 1`;
}

// ============== Perft ==============
// l() returns fully legal destinations, so no legality filter is needed here.
// Promotions are expanded to four moves, as perft requires.
function makePerft(env) {
  const snap = () => ({ b: env.b.slice(), c: env.c, e: env.e, n: env.n, t: env.t });
  const restore = st => { env.b = st.b; env.c = st.c; env.e = st.e; env.n = st.n; env.t = st.t; };
  const PROMOS = ['q', 'r', 'b', 'n'];

  function perft(depth) {
    if (depth === 0) return 1;
    let nodes = 0;
    const side = env.t;
    for (let from = 0; from < 64; from++) {
      const p = env.b[from];
      if (!D.own(p, side)) continue;
      const isPawn = D.pawn(p);
      for (const to of env.L(from)) {
        const promo = isPawn && (to < 8 || to >= 56);
        for (const q of (promo ? PROMOS : ['q'])) {
          const st = snap();
          // Castling rights are updated by hand. engine_4x.js needs it: there the
          // line lives in the search, not in M(). engine.js, engine_string.js and
          // engine_onlyMoveGenerator.js clear the bits inside M() themselves, so
          // for those this is a repeat — harmless, the mask is idempotent. A()
          // would also do it, but A() flips t and counts repetitions, which perft
          // must not. Do not delete this line: 4x would silently lose castling.
          env.c &= ~env.C(from) & ~env.C(to);
          env.M(from, to, D.promo(q));
          env.t ^= 1;
          nodes += perft(depth - 1);
          restore(st);
        }
      }
    }
    return nodes;
  }
  return perft;
}

function legalMoves(env) {
  const moves = [];
  const side = env.t;
  for (let i = 0; i < 64; i++) {
    const p = env.b[i];
    if (!D.own(p, side)) continue;
    const isPawn = D.pawn(p);
    for (const to of env.L(i)) {
      if (isPawn && (to < 8 || to >= 56)) {
        for (const q of ['q', 'r', 'b', 'n']) moves.push(sqName(i) + sqName(to) + q);
      } else moves.push(sqName(i) + sqName(to));
    }
  }
  return moves.sort();
}

// ============== Stockfish ==============
const SF = process.env.STOCKFISH ||
  (process.platform === 'win32' ? 'stockfish.exe' :
    (fs.existsSync('/usr/games/stockfish') ? '/usr/games/stockfish' :
      fs.existsSync('/usr/bin/stockfish') ? '/usr/bin/stockfish' :
        fs.existsSync('/opt/homebrew/bin/stockfish') ? '/opt/homebrew/bin/stockfish' : 'stockfish'));

function sfRun(input, timeoutMs = 600000) {
  const r = spawnSync(SF, [], { input, encoding: 'utf8', timeout: timeoutMs, maxBuffer: 64 * 1024 * 1024 });
  if (r.error) throw r.error;
  return (r.stdout || '') + (r.stderr || '');
}
function hasStockfish() { try { return /Stockfish/i.test(sfRun('quit\n', 5000)); } catch { return false; } }
function sfPerft(fen, depth) {
  const out = sfRun(`position fen ${fen}\ngo perft ${depth}\nquit\n`);
  const m = out.match(/Nodes searched:\s*(\d+)/);
  return m ? +m[1] : null;
}
function sfLegalMoves(fen) {
  const out = sfRun(`position fen ${fen}\ngo perft 1\nquit\n`);
  const moves = [];
  for (const line of out.split(/\r?\n/)) {
    const m = line.match(/^([a-h][1-8][a-h][1-8][qrbn]?):\s*1\s*$/);
    if (m) moves.push(m[1]);
  }
  return moves.sort();
}

// ============== Reference positions ==============
// Node counts from the Chess Programming Wiki Perft Results page. The table
// intentionally runs deeper than this harness will normally compute: a present
// but unreachable entry costs nothing, whereas a MISSING entry silently
// downgrades a correct run to "(no reference)".
const CPW = [
  { name: "Start", fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
    expected: { 1: 20, 2: 400, 3: 8902, 4: 197281, 5: 4865609, 6: 119060324, 7: 3195901860, 8: 84998978956 } },
  { name: "Kiwipete", fen: "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    expected: { 1: 48, 2: 2039, 3: 97862, 4: 4085603, 5: 193690690, 6: 8031647685 } },
  { name: "Position3", fen: "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    expected: { 1: 14, 2: 191, 3: 2812, 4: 43238, 5: 674624, 6: 11030083, 7: 178633661, 8: 3009794393 } },
  { name: "Position4", fen: "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
    expected: { 1: 6, 2: 264, 3: 9467, 4: 422333, 5: 15833292, 6: 706045033 } },
  { name: "Position4Mirror", fen: "r2q1rk1/pP1p2pp/Q4n2/bbp1p3/Np6/1B3NBn/pPPP1PPP/R3K2R b KQ - 0 1",
    expected: { 1: 6, 2: 264, 3: 9467, 4: 422333, 5: 15833292, 6: 706045033 } },
  { name: "Position5", fen: "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
    expected: { 1: 44, 2: 1486, 3: 62379, 4: 2103487, 5: 89941194 } },
  { name: "Position6", fen: "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
    expected: { 1: 46, 2: 2079, 3: 89890, 4: 3894594, 5: 164075551, 6: 6923051137, 7: 287188994746 } },
];

const TRICKY = [
  { name: "Illegal ep #1",               fen: "3k4/3p4/8/K1P4r/8/8/8/8 b - - 0 1",         ref: { 1: 18, 2: 92, 3: 1670, 6: 1134888 } },
  { name: "Illegal ep #2",               fen: "8/8/4k3/8/2p5/8/B2P2K1/8 w - - 0 1",        ref: { 1: 13, 2: 102, 3: 1266, 6: 1015133 } },
  { name: "EP capture checks opp.",      fen: "8/8/1k6/2b5/2pP4/8/5K2/8 b - d3 0 1",       ref: { 1: 15, 2: 126, 3: 1928, 6: 1440467 } },
  { name: "Short castling gives check",  fen: "5k2/8/8/8/8/8/8/4K2R w K - 0 1",            ref: { 1: 15, 2: 66, 3: 1198, 6: 661072 } },
  { name: "Long castling gives check",   fen: "3k4/8/8/8/8/8/8/R3K3 w Q - 0 1",            ref: { 1: 16, 2: 71, 3: 1286, 6: 803711 } },
  { name: "Castle Rights",               fen: "r3k2r/1b4bq/8/8/8/8/7B/R3K2R w KQkq - 0 1", ref: { 1: 26, 2: 1141, 3: 27826, 4: 1274206 } },
  { name: "Castling Prevented",          fen: "r3k2r/8/3Q4/8/8/5q2/8/R3K2R b KQkq - 0 1",  ref: { 1: 44, 2: 1494, 3: 50509, 4: 1720476 } },
  { name: "Promote out of Check",        fen: "2K2r2/4P3/8/8/8/8/8/3k4 w - - 0 1",         ref: { 1: 11, 2: 133, 3: 1442, 6: 3821001 } },
  { name: "Discovered Check",            fen: "8/8/1P2K3/8/2n5/1q6/8/5k2 b - - 0 1",       ref: { 1: 29, 2: 165, 3: 5160, 5: 1004658 } },
  { name: "Promote to give check",       fen: "4k3/1P6/8/8/8/8/K7/8 w - - 0 1",            ref: { 1: 9, 2: 40, 3: 472, 6: 217342 } },
  { name: "Under Promote to give check", fen: "8/P1k5/K7/8/8/8/8/8 w - - 0 1",             ref: { 1: 6, 2: 27, 3: 273, 6: 92683 } },
  { name: "Self Stalemate",              fen: "K1k5/8/P7/8/8/8/8/8 w - - 0 1",             ref: { 1: 2, 2: 6, 3: 13, 6: 2217 } },
  { name: "Stalemate & Checkmate I",     fen: "8/k1P5/8/1K6/8/8/8/8 w - - 0 1",            ref: { 1: 10, 2: 25, 3: 268, 7: 567584 } },
  { name: "Stalemate & Checkmate II",    fen: "8/8/2k5/5q2/5n2/8/5K2/8 b - - 0 1",         ref: { 1: 37, 2: 183, 3: 6559, 4: 23527 } },
  { name: "Bishop pin avoid",            fen: "1k6/1b6/8/8/7R/8/8/4K2R b K - 0 1",         ref: { 1: 13, 2: 284, 3: 3529, 5: 1063513 } },
];

const POS_ALIAS = {
  start: 'Start', kiwipete: 'Kiwipete', pos2: 'Kiwipete',
  pos3: 'Position3', pos4: 'Position4', pos4m: 'Position4Mirror',
  pos5: 'Position5', pos6: 'Position6',
};

const fmt = n => n.toLocaleString('en-US');

// Which rungs of the ladder are present, so a run on a lower level is never
// mistaken for a run on the full engine.
const LEVELS = {
  './engine_4x.js': 'full FIDE, speed build, numeric board',
  './engine.js': 'full FIDE, byte-record build, numeric board',
  './engine_string.js': 'full FIDE, string board (FEN letters)',
  './engine_onlyMoveGenerator.js': 'move generation only, numeric board',
};

function banner() {
  const src = readEngine();
  const level = LEVELS[ENGINE_FILE];
  const skipped = ENGINE_CANDIDATES.slice(0, ENGINE_CANDIDATES.indexOf(ENGINE_FILE))
    .filter(p => !fs.existsSync(here(p.slice(2)))).length;
  console.log(`\nEngine: ${ENGINE_FILE}  (${Buffer.byteLength(src, 'utf8')} B of core)`
    + (level ? `\n        ${level}` : '')
    + (skipped ? `  [${skipped} higher level(s) not in this folder]` : ''));
  return src;
}

// ============== Command: detect ==============
function cmdDetect() {
  const src = banner();
  const env = loadEngine();
  console.log(`\n  API present:`);
  for (const [fn, what] of [['L', 'legal moves'], ['M', 'apply move'], ['A', 'play real move'],
                            ['Z', 'result code'], ['D', 'draw claim'], ['F', 'flag/resign'],
                            ['l', 'check'], ['H', 'FIDE 6.9'], ['I', 'insufficient material'],
                            ['C', 'castling bits'], ['G', 'geometry']]) {
    console.log(`    ${typeof env[fn] === 'function' ? '+' : '-'} ${fn.padEnd(2)} ${what}`);
  }
  console.log(`\n  initial state: c=${env.c} t=${env.t} e=${env.e} n=${env.n}`);
  const sig = /^c=15,U=[^,\]]*(\[[^\]]*\])?,N=[^,]*,e=Y=/.test(src.trim());
  console.log(`  signature c U N e Y t: ${sig ? 'present' : 'absent'}  (U: ${Array.isArray(env.U) ? 'clock array' : typeof env.U}, N: ${JSON.stringify(env.N)})`);
  // Castling bit semantics, checked rather than assumed.
  const bits = [0, 4, 7, 56, 60, 63].map(i => `${sqName(i)}=${env.C(i)}`).join(' ');
  console.log(`  castling bits: ${bits}`);
  console.log(`  board: ${env.b.length} squares, a1=${JSON.stringify(env.b[X(0)])} h8=${JSON.stringify(env.b[X(63)])}`);
  console.log(`  dialect: ${D.string ? "string (FEN letters, '-' empty)" : 'numeric (type*2+colour, 0 empty)'}`);
  console.log(`\n  Stockfish: ${hasStockfish() ? 'found (' + SF + ')' : 'NOT found'}\n`);
}

// ============== Command: sanity ==============
function cmdSanity() {
  banner();
  const env = loadEngine();
  const perft = makePerft(env);
  const cases = [
    ['Start', CPW[0].fen, 3, 8902],
    ['Position3', CPW[2].fen, 3, 2812],
    ['Kiwipete', CPW[1].fen, 3, 97862],
  ];
  let pass = 0;
  console.log('');
  for (const [name, fen, d, exp] of cases) {
    setFEN(env, fen);
    const got = perft(d);
    const ok = got === exp;
    if (ok) pass++;
    console.log(`  ${name}: ${fmt(got)} ${ok ? '\u2713' : '\u2717 expected ' + fmt(exp)}`);
  }
  console.log(`\nSanity: ${pass}/${cases.length} passed\n`);
  return pass === cases.length;
}

// ============== Command: cpw ==============
function cmdCPW(maxDepth = 4, minDepth = 1) {
  banner();
  const env = loadEngine();
  const perft = makePerft(env);
  let pass = 0, fail = 0, skip = 0;
  console.log('');
  for (const pos of CPW) {
    console.log(`${pos.name}:`);
    for (let d = +minDepth; d <= +maxDepth; d++) {
      const exp = pos.expected[d];
      if (exp == null) { console.log(`  d${d}: (no reference)`); skip++; continue; }
      const t0 = Date.now();
      setFEN(env, pos.fen);
      const got = perft(d);
      const secs = ((Date.now() - t0) / 1000).toFixed(1);
      const ok = got === exp;
      ok ? pass++ : fail++;
      console.log(`  d${d}: ${fmt(got)} ${ok ? '\u2713' : '\u2717 expected ' + fmt(exp)} (${secs}s)`);
    }
  }
  console.log(`\nCPW: ${pass} passed, ${fail} failed${skip ? ', ' + skip + ' without reference' : ''}\n`);
  return fail === 0;
}

// ============== Command: pos ==============
function cmdPos(name, depth) {
  banner();
  const key = POS_ALIAS[String(name).toLowerCase()] || name;
  const pos = CPW.find(p => p.name.toLowerCase() === String(key).toLowerCase());
  if (!pos) { console.error(`Unknown position: ${name}\nKnown: ${Object.keys(POS_ALIAS).join(' ')}`); process.exit(1); }
  const env = loadEngine();
  const perft = makePerft(env);
  const d = +depth;
  const exp = pos.expected[d];
  console.log(`\n${pos.name} d${d}${exp != null ? '  (expected ' + fmt(exp) + ')' : ''}`);
  const t0 = Date.now();
  setFEN(env, pos.fen);
  const got = perft(d);
  const secs = ((Date.now() - t0) / 1000).toFixed(1);
  if (exp == null) { console.log(`  ${fmt(got)}  (no reference) (${secs}s)\n`); return true; }
  const ok = got === exp;
  console.log(`  ${fmt(got)} ${ok ? '\u2713 [published \u2713]' : '\u2717 expected ' + fmt(exp)} (${secs}s)\n`);
  return ok;
}

// ============== Command: verify (vs Stockfish) ==============
function cmdVerify(fen, depth) {
  banner();
  if (!hasStockfish()) { console.error('ERROR: verify requires Stockfish.'); process.exit(1); }
  const env = loadEngine();
  const perft = makePerft(env);
  const d = +depth;
  console.log(`\nFEN: ${fen}\nDepth: ${d}`);
  const t0 = Date.now();
  setFEN(env, fen);
  const got = perft(d);
  const secs = ((Date.now() - t0) / 1000).toFixed(1);
  const sf = sfPerft(fen, d);
  const ok = sf != null && got === sf;
  console.log(`  newengine: ${fmt(got)} (${secs}s)`);
  console.log(`  Stockfish: ${sf == null ? '(failed)' : fmt(sf)}  ${ok ? 'SF=' + fmt(sf) + ' \u2713' : '\u2717'}\n`);
  return ok;
}

// ============== Command: perft / divide ==============
function cmdPerft(fen, depth) {
  const env = loadEngine();
  const perft = makePerft(env);
  setFEN(env, fen);
  const t0 = Date.now();
  const got = perft(+depth);
  console.log(`${fmt(got)}  (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  return true;
}

function cmdDivide(fen, depth) {
  const env = loadEngine();
  const perft = makePerft(env);
  const d = +depth;
  setFEN(env, fen);
  const snap = () => ({ b: env.b.slice(), c: env.c, e: env.e, n: env.n, t: env.t });
  const restore = st => { env.b = st.b; env.c = st.c; env.e = st.e; env.n = st.n; env.t = st.t; };
  let total = 0;
  const out = [];
  for (let from = 0; from < 64; from++) {
    const p = env.b[from];
    if (!D.own(p, env.t)) continue;
    const isPawn = D.pawn(p);
    for (const to of env.L(from)) {
      const promo = isPawn && (to < 8 || to >= 56);
      for (const q of (promo ? ['q', 'r', 'b', 'n'] : ['q'])) {
        const st = snap();
        env.c &= ~env.C(from) & ~env.C(to);
        env.M(from, to, D.promo(q));
        env.t ^= 1;
        const sub = d > 1 ? perft(d - 1) : 1;
        restore(st);
        out.push(`${sqName(from)}${sqName(to)}${promo ? q : ''}: ${sub}`);
        total += sub;
      }
    }
  }
  out.sort();
  for (const l of out) console.log(l);
  console.log(`\nNodes searched: ${total}`);
  return true;
}

// ============== Command: tricky ==============
function cmdTricky(maxDepth = 4) {
  banner();
  const useSF = hasStockfish();
  console.log(useSF ? 'Stockfish: cross-checking enabled' : 'Stockfish: not found (reference values only)');
  const env = loadEngine();
  const perft = makePerft(env);
  let pass = 0, fail = 0;
  console.log('');
  for (const pos of TRICKY) {
    // Each position has its OWN published depth; never exceed it pointlessly.
    const published = Math.max(...Object.keys(pos.ref).map(Number));
    const d = Math.min(+maxDepth, published);
    const exp = pos.ref[d];
    const t0 = Date.now();
    setFEN(env, pos.fen);
    const got = perft(d);
    const secs = ((Date.now() - t0) / 1000).toFixed(1);
    let line = `  ${pos.name.padEnd(30)} d${d}: ${fmt(got)}`;
    let ok = true;
    if (exp != null) {
      ok = got === exp;
      // d1-d3 entries are not published: they were generated by an independent
      // reference implementation and agree with newengine. Label them honestly.
      const tag = d >= 4 ? '[published \u2713]' : '[ref \u2713]';
      line += ok ? ` \u2713 ${tag}` : ` \u2717 expected ${fmt(exp)}`;
    } else {
      const sf = useSF ? sfPerft(pos.fen, d) : null;
      if (sf != null) { ok = got === sf; line += ok ? ` SF=${fmt(sf)} \u2713` : ` \u2717 SF=${fmt(sf)}`; }
      else line += ' (no reference)';
    }
    if (useSF && exp != null) {
      const sf = sfPerft(pos.fen, d);
      if (sf != null && sf !== got) { ok = false; line += ` \u2717 SF=${fmt(sf)}`; }
      else if (sf != null) line += ` SF=${fmt(sf)} \u2713`;
    }
    line += ` (${secs}s)`;
    ok ? pass++ : fail++;
    console.log(line);
  }
  console.log(`\nTricky: ${pass} passed, ${fail} failed\n`);
  return fail === 0;
}

// ============== Command: vajolet ==============
function cmdVajolet(n = 30, maxDepth = 3, startIdx = 0) {
  banner();
  const file = process.env.VAJOLET || './vajolet_perft.txt';
  if (!fs.existsSync(file)) { console.error(`ERROR: ${file} not found`); process.exit(1); }
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(l => l.trim());
  const env = loadEngine();
  const perft = makePerft(env);
  let pass = 0, fail = 0;
  const failures = [];
  const end = Math.min(+startIdx + +n, lines.length);
  console.log(`\n${lines.length} positions in file; running ${+startIdx}..${end - 1} to depth ${maxDepth}\n`);
  for (let idx = +startIdx; idx < end; idx++) {
    const parts = lines[idx].split(',');
    const fen = parts[0].trim() + ' 0 1';
    let row = `  [${String(idx + 1).padStart(3)}] `;
    let bad = false;
    for (let d = 1; d <= +maxDepth; d++) {
      const exp = parts[d] != null ? +parts[d] : null;
      if (exp == null || Number.isNaN(exp)) continue;
      setFEN(env, fen);
      const got = perft(d);
      if (got === exp) { pass++; row += `d${d}\u2713 `; }
      else { fail++; bad = true; row += `d${d}\u2717(${fmt(got)}\u2260${fmt(exp)}) `; }
    }
    if (bad) failures.push({ idx: idx + 1, fen });
    console.log(row);
  }
  console.log(`\nVajolet: ${pass} passed, ${fail} failed`);
  for (const f of failures.slice(0, 5)) console.log(`  FAIL [${f.idx}] ${f.fen}`);
  console.log('');
  return fail === 0;
}

// ============== Command: random (vs Stockfish) ==============
function cmdRandom(start, games = 20, maxPlies = 60) {
  banner();
  if (!hasStockfish()) { console.error('ERROR: random requires Stockfish.'); process.exit(1); }
  const PRESETS = {
    standard: CPW[0].fen, start: CPW[0].fen, kiwipete: CPW[1].fen,
    pos3: CPW[2].fen, pos4: CPW[3].fen, pos5: CPW[5].fen,
  };
  const fen = PRESETS[start] || start;
  const env = loadEngine();
  let ok = 0; const mismatches = [];
  console.log('');
  for (let g = 0; g < +games; g++) {
    setFEN(env, fen);
    let rng = (g + 1) | 0, fault = null;
    for (let ply = 0; ply < +maxPlies; ply++) {
      const curFEN = envToFEN(env);
      const fl = legalMoves(env);
      const sf = sfLegalMoves(curFEN);
      if (fl.length !== sf.length || fl.some((m, i) => m !== sf[i])) { fault = { ply, fen: curFEN, fl, sf }; break; }
      if (fl.length === 0 || env.n > 100) break;
      rng = (rng * 1664525 + 1013904223) | 0;
      const choice = fl[Math.abs(rng) % fl.length];
      const from = nameSq(choice.slice(0, 2)), to = nameSq(choice.slice(2, 4));
      env.c &= ~env.C(from) & ~env.C(to);
      env.M(from, to, D.promo(choice.length === 5 ? choice[4] : 'q'));
      env.t ^= 1;
    }
    if (fault) { mismatches.push({ g: g + 1, ...fault }); process.stdout.write('X'); }
    else { ok++; process.stdout.write('.'); }
  }
  console.log(`\n\nRandom: ${ok}/${games} fully matching`);
  for (const m of mismatches.slice(0, 3)) {
    console.log(`\nGame ${m.g} ply ${m.ply}:\n  FEN: ${m.fen}`);
    const onlyFL = m.fl.filter(x => !m.sf.includes(x));
    const onlySF = m.sf.filter(x => !m.fl.includes(x));
    if (onlyFL.length) console.log(`  engine only: ${onlyFL.join(' ')}`);
    if (onlySF.length) console.log(`  SF only    : ${onlySF.join(' ')}`);
  }
  console.log('');
  return mismatches.length === 0;
}

// ============== Command: all ==============
function cmdAll() {
  const results = [];
  results.push(['sanity', cmdSanity()]);
  results.push(['cpw d4', cmdCPW(4)]);
  results.push(['tricky d4', cmdTricky(4)]);
  if (fs.existsSync(process.env.VAJOLET || './vajolet_perft.txt')) results.push(['vajolet 20 d3', cmdVajolet(20, 3)]);
  console.log('=========================');
  for (const [n, ok] of results) console.log(`  ${ok ? '\u2713' : '\u2717'} ${n}`);
  const bad = results.filter(r => !r[1]).length;
  console.log(`=========================\n${bad ? bad + ' SUITE(S) FAILED' : 'ALL PASSED'}\n`);
  return bad === 0;
}

// ============== main ==============
const [, , cmd, ...args] = process.argv;
const USAGE = `
newengine test suite

  node test.js detect                        report API / castling bits / Stockfish
  node test.js sanity                        quick check (d3)
  node test.js cpw [maxD] [minD]             CPW positions over a depth range
  node test.js pos <name> <depth>            single position (start/kiwipete/pos3..pos6/pos4m)
  node test.js verify "<FEN>" <depth>        engine vs Stockfish, any position
  node test.js tricky [maxD]                 van Kervinck tricky positions
  node test.js vajolet [N] [maxD] [startIdx] Vajolet CSV suite
  node test.js random <preset|FEN> [games] [plies]   move-list equality vs Stockfish
  node test.js perft "<FEN>" <depth>         raw perft
  node test.js divide "<FEN>" <depth>        divide perft (debugging)
  node test.js all                           sanity + cpw d4 + tricky d4 + vajolet
  node test.js pick                          ask once, print the chosen engine path

Engine: a picker appears when a command is given. Skip it with
  ENGINE=./engine_string.js node test.js sanity
  node test.js sanity --engine=3            (1 4x, 2 engine, 3 string, 4 movegen)

A script that runs several commands should ask once and pin the answer:
  for /f "usebackq delims=" %%e in (\`node test.js pick\`) do set "ENGINE=%%e"
`;

ENGINE_FILE = pickEngine(!!cmd && cmd !== 'help' && cmd !== '--help');

let okExit = true;
switch (cmd) {
  case 'detect': cmdDetect(); break;
  case 'sanity': okExit = cmdSanity(); break;
  case 'cpw': okExit = cmdCPW(args[0] ?? 4, args[1] ?? 1); break;
  case 'pos': okExit = cmdPos(args[0], args[1]); break;
  case 'verify': okExit = cmdVerify(args[0], args[1]); break;
  case 'perft': okExit = cmdPerft(args[0], args[1]); break;
  case 'divide': okExit = cmdDivide(args[0], args[1]); break;
  case 'tricky': okExit = cmdTricky(args[0] ?? 4); break;
  case 'vajolet': okExit = cmdVajolet(args[0] ?? 30, args[1] ?? 3, args[2] ?? 0); break;
  case 'random': okExit = cmdRandom(args[0] ?? 'kiwipete', args[1] ?? 20, args[2] ?? 60); break;
  case 'all': okExit = cmdAll(); break;
  case 'pick': process.stdout.write(ENGINE_FILE + '\n'); break;
  default: console.log(USAGE);
}
process.exit(okExit ? 0 : 1);
